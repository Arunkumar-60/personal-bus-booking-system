import React from 'react'

const About = () => {
  return (
    <div className='h-screen flex justify-center items-center w-full bg-neutral-950'>
        <div className="text-5xl text-neutral-50 font-bold">
            this is the about page section
        </div>
    </div>
  )
}

export default About
